import logo from './logo.svg';
import './App.css';
import  Board from './Game/Board';

function App() {
  return (
    <Board/>
  );
}

export default App;
